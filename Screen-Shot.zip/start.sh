kill -9 `pgrep -f "gunicorn app:app"`
gunicorn app:app -b 0.0.0.0:8080 --workers 4 --reload --daemon