from flask import Flask,render_template,redirect,request
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import time

app = Flask(__name__)

@app.route('/',methods = ['POST','GET'])
def index():
    if request.method == 'POST':
        url = request.form['content']
        try:
            chrome_options = Options()
            chrome_options.add_argument('--headless')
            chrome_options.add_argument('--start-maximized')
            driver = webdriver.Chrome(chrome_options=chrome_options)
            #url = input("Enter a url: ")
            driver.get("http://"+url)


            tot = driver.maximize_window()
            ele = driver.find_element_by_tag_name('body')
            
            total_height = ele.size["height"]+8000
            required_width = driver.execute_script('return document.body.parentNode.scrollWidth')
            required_height = driver.execute_script('return document.body.parentNode.scrollHeight')
#print(driver.set_window_size(1920,required_height))     
            driver.set_window_size(required_width,required_height) #the trick
 

            driver.save_screenshot(url+".png")
            driver.quit()

        except:
            return "There's something wrong ,try later! "

            
    return render_template('index.html')


if __name__ == "__main__":
    app.run(debug=True)